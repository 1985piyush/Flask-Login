# -*- coding: utf-8 -*-
"""
Created on Sun Apr 27 13:07:24 2025

@author: Piyush.Singh
"""

from flask import Flask, render_template,request

app=Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/register',methods=['GET','POST'])
def register():
    if request.method=="POST":
        name=request.form.get("name")
        age=request.form.get("age")
        city=request.form.get("city")
        return render_template('registration success.html', name=name,age=age,city=city)
    


if __name__=="__main__":
    app.run(debug=True)